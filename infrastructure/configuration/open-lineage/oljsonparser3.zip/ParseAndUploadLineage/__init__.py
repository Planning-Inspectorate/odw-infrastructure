import logging, os, json, re
from typing import List, Dict
from azure.storage.blob import BlobClient

from pyapacheatlas.auth import ServicePrincipalAuthentication
from pyapacheatlas.core import PurviewClient, AtlasEntity, AtlasProcess
from pyapacheatlas.core.util import GuidTracker
from pyapacheatlas.core.typedef import AtlasAttributeDef, EntityTypeDef

PURVIEW_NAME   = os.environ.get("PURVIEW_NAME")
TENANT_ID      = os.environ.get("TENANT_ID")
CLIENT_ID      = os.environ.get("CLIENT_ID")
CLIENT_SECRET  = os.environ.get("CLIENT_SECRET")

# Dataset & Process config
INPUT_TYPE     = os.environ.get("INPUT_ENTITY_TYPE",  "azure_datalake_gen2_resource_set")
OUTPUT_TYPE    = os.environ.get("OUTPUT_ENTITY_TYPE", "azure_datalake_gen2_resource_set")
PROCESS_TYPE   = os.environ.get("PROCESS_ENTITY_TYPE","azure_synapse_operation")
ENABLE_COL_MAP = os.environ.get("ENABLE_COLUMN_MAPPING","true").lower() == "true"
DEFAULT_MAP_IDENTITY = os.environ.get("DEFAULT_COL_MAP_IDENTITY","true").lower() == "true"

# QualifiedName mapping: pass-through or custom normalization
def normalize_qn(path: str) -> str:
    # Expect abfss://<container>@<account>.dfs.core.windows.net/<path>
    # If event already provides a fully qualified path, return as-is.
    # Otherwise, you can transform your incoming dataset URIs here.
    return path

def _ensure_types(client: PurviewClient):
    # Ensure our Process type exists and has a string columnMapping attribute
    typedef = EntityTypeDef(
        name=PROCESS_TYPE,
        superTypes=["Process"],
        attributes=[AtlasAttributeDef(name="columnMapping")]
    )
    try:
        client.upload_typedefs(entityDefs=[typedef], force_update=True)
    except Exception:
        # If the type exists, ignore
        pass

def _build_column_mapping(inputs: List[str], outputs: List[str], cols_in: List[str], cols_out: List[str]) -> str:
    # Build one dataset-level mapping for the first input->first output for simplicity.
    if not inputs or not outputs:
        return "[]"
    src = inputs[0]
    sink = outputs[0]
    mapping = []
    if not cols_in or not cols_out:
        # No explicit columns available: identity map if enabled
        if DEFAULT_MAP_IDENTITY:
            pairs = [{"Source": c, "Sink": c} for c in set(cols_in or []) & set(cols_out or [])]
        else:
            pairs = []
    else:
        # Map by name intersection
        intersect = set(cols_in) & set(cols_out)
        pairs = [{"Source": c, "Sink": c} for c in sorted(intersect)]
    mapping.append({
        "DatasetMapping": {"Source": src, "Sink": sink},
        "ColumnMapping": pairs
    })
    return json.dumps(mapping, separators=(",",":"))

def _extract_columns_from_facets(evt: Dict) -> (List[str], List[str]):
    # Try to extract column names from OpenLineage facets if present.
    # This is heuristic; different producers may populate different facets.
    cols_in = []
    cols_out = []
    try:
        for ds in evt.get("inputs", []) or []:
            fields = (ds.get("facets", {}) or {}).get("schema", {}) or {}
            names = [f.get("name") for f in (fields.get("fields") or []) if isinstance(f, dict) and f.get("name")]
            cols_in.extend(names)
        for ds in evt.get("outputs", []) or []:
            fields = (ds.get("facets", {}) or {}).get("schema", {}) or {}
            names = [f.get("name") for f in (fields.get("fields") or []) if isinstance(f, dict) and f.get("name")]
            cols_out.extend(names)
    except Exception:
        pass
    # Deduplicate
    cols_in  = sorted(list(set([c for c in cols_in if c])))
    cols_out = sorted(list(set([c for c in cols_out if c])))
    return cols_in, cols_out

def main(blob: bytes):
    logging.info("ParseAndUploadLineage triggered. Size: %s bytes", len(blob) if blob else 0)
    evt = json.loads(blob.decode("utf-8"))

    # Prepare client
    spa = ServicePrincipalAuthentication(tenant_id=TENANT_ID, client_id=CLIENT_ID, client_secret=CLIENT_SECRET)
    client = PurviewClient(account_name=PURVIEW_NAME, authentication=spa)

    _ensure_types(client)

    # Resolve inputs/outputs qualified names
    def ds_qn_list(kind: str) -> List[str]:
        ds = evt.get(kind, []) or []
        qns = []
        for d in ds:
            # Prefer 'name' or 'uri' fields depending on producer
            qn = d.get("name") or d.get("uri") or d.get("namespace")
            if not qn and d.get("facets", {}).get("dataSource", {}).get("name"):
                qn = d["facets"]["dataSource"]["name"]
            if qn:
                qns.append(normalize_qn(qn))
        return qns

    input_qns  = ds_qn_list("inputs")
    output_qns = ds_qn_list("outputs")

    # Build entities
    gt = GuidTracker()
    entities = []
    input_entities = []
    output_entities = []

    for qn in input_qns:
        input_entities.append(AtlasEntity(
            typeName=INPUT_TYPE, qualified_name=qn, name=os.path.basename(qn), guid=gt.get_guid()
        ))
    for qn in output_qns:
        output_entities.append(AtlasEntity(
            typeName=OUTPUT_TYPE, qualified_name=qn, name=os.path.basename(qn), guid=gt.get_guid()
        ))

    entities.extend(input_entities)
    entities.extend(output_entities)

    # Process entity
    job = evt.get("job", {}) or {}
    run = evt.get("run", {}) or {}

    namespace = job.get("namespace") or "synapse"
    job_name  = job.get("name") or "notebook"
    run_id    = run.get("runId") or "run"

    process_qn = f"synapse://{namespace}/{job_name}/{run_id}"
    attributes = {}

    if ENABLE_COL_MAP:
        cols_in, cols_out = _extract_columns_from_facets(evt)
        attributes["columnMapping"] = _build_column_mapping(input_qns, output_qns, cols_in, cols_out)

    proc = AtlasProcess(
        typeName=PROCESS_TYPE,
        qualified_name=process_qn,
        name=job_name,
        guid=gt.get_guid(),
        inputs=input_entities,
        outputs=output_entities,
        attributes=attributes
    )

    entities.append(proc)

    # Upload together
    res = client.upload_entities(entities=entities)
    logging.info("Uploaded entities response: %s", res)