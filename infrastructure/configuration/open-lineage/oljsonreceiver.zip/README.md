# ol-json-receiver (production)

HTTP endpoint for OpenLineage events from Synapse Spark.

## App settings
- STORAGE_CONNECTION
- EVENTS_CONTAINER = openlineage-events
- DEADLETTER_CONTAINER = openlineage-deadletter
- TABLE_NAME = LineageJobs
- ALLOWED_EVENT_TYPES = COMPLETE
- ALLOW_SQL_ONLY = true
- MAX_CONTENT_LENGTH = 8388608
- WRITE_TABLE = true

## Endpoint
POST /api/ingest (use Function key)